package com.jarvis.app

import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build

/** Heuristic safety checker. It does not claim to prove an app is a virus. */
object JarvisSecurityScanner {
    data class Finding(val label: String, val score: Int, val reasons: List<String>)

    fun scan(pm: PackageManager): List<Finding> {
        val apps = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_LAUNCHER), PackageManager.ResolveInfoFlags.of(0))
                .mapNotNull { it.activityInfo?.applicationInfo }.distinctBy { it.packageName }
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_LAUNCHER), 0)
                .mapNotNull { it.activityInfo?.applicationInfo }.distinctBy { it.packageName }
        }
        return apps.mapNotNull { app -> inspect(pm, app) }.sortedByDescending { it.score }
    }

    private fun inspect(pm: PackageManager, app: ApplicationInfo): Finding? {
        if (app.packageName == "com.jarvis.app") return null
        val pkg: PackageInfo = try {
            if (Build.VERSION.SDK_INT >= 33) pm.getPackageInfo(app.packageName, PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong()))
            else @Suppress("DEPRECATION") pm.getPackageInfo(app.packageName, PackageManager.GET_PERMISSIONS)
        } catch (_: Exception) { return null }
        val permissions = pkg.requestedPermissions?.toSet().orEmpty()
        val reasons = mutableListOf<String>()
        var score = 0
        fun risk(permission: String, points: Int, reason: String) {
            if (permissions.contains(permission)) { score += points; reasons += reason }
        }
        risk("android.permission.REQUEST_INSTALL_PACKAGES", 4, "สามารถขอติดตั้งแพ็กเกจได้")
        risk("android.permission.SYSTEM_ALERT_WINDOW", 3, "สามารถแสดงหน้าต่างทับแอปอื่นได้")
        risk("android.permission.RECORD_AUDIO", 1, "ใช้ไมโครโฟนได้")
        risk("android.permission.CAMERA", 1, "ใช้กล้องได้")
        risk("android.permission.READ_SMS", 3, "อ่าน SMS ได้")
        risk("android.permission.RECEIVE_SMS", 3, "รับ SMS ได้")
        risk("android.permission.READ_CONTACTS", 1, "อ่านรายชื่อติดต่อได้")
        risk("android.permission.ACCESS_FINE_LOCATION", 1, "เข้าถึงตำแหน่งได้")
        if ((app.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) { score += 1; reasons += "เป็นแอปที่เปิดโหมด debug" }
        return if (score >= 4) {
            Finding(app.loadLabel(pm).toString(), score, reasons)
        } else null
    }
}
