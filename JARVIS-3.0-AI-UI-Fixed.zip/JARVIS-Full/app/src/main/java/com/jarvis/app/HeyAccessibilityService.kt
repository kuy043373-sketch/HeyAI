package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Build

class HeyAccessibilityService : AccessibilityService() {
    private var indicator: View? = null
    private var windowManager: WindowManager? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        current = this
        MainActivity.instance?.refreshScreenSummary()
    }

    override fun onInterrupt() = Unit

    override fun onServiceConnected() {
        super.onServiceConnected()
        current = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        MainActivity.instance?.refreshScreenSummary()
    }

    fun setListeningIndicator(show: Boolean) {
        if (show) showIndicator() else hideIndicator()
    }

    private fun showIndicator() {
        if (indicator != null || windowManager == null) return
        val density = resources.displayMetrics.density
        val size = (11 * density).toInt().coerceAtLeast(8)
        val margin = (8 * density).toInt()
        val dot = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.WHITE)
                setStroke((1 * density).toInt().coerceAtLeast(1), Color.argb(90, 160, 160, 160))
            }
            alpha = 0.96f
            isClickable = false
            isFocusable = false
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1)
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        else WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
        val params = WindowManager.LayoutParams(
            size, size, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = margin
            y = margin
        }
        try {
            windowManager?.addView(dot, params)
            indicator = dot
        } catch (_: Exception) { indicator = null }
    }

    private fun hideIndicator() {
        val v = indicator ?: return
        try { windowManager?.removeView(v) } catch (_: Exception) { }
        indicator = null
    }

    fun readVisibleText(): String {
        val root = rootInActiveWindow ?: return "ยังอ่านหน้าจอไม่ได้"
        val out = StringBuilder()
        collect(root, out)
        root.recycle()
        return out.toString().trim().ifEmpty { "ไม่พบข้อความหรือองค์ประกอบที่อ่านได้บนหน้าจอ" }
    }

    private fun collect(node: AccessibilityNodeInfo, out: StringBuilder) {
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) out.append(text).append('\n')
        else if (desc.isNotEmpty()) out.append(desc).append('\n')
        for (i in 0 until node.childCount) node.getChild(i)?.let { child -> collect(child, out); child.recycle() }
    }

    override fun onDestroy() {
        hideIndicator()
        if (current === this) current = null
        super.onDestroy()
    }

    companion object { var current: HeyAccessibilityService? = null }
}
