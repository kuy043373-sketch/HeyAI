package com.jarvis.app

import java.text.Normalizer
import java.util.Locale

/** Natural-language local brain. It maps many ways of saying the same thing to safe phone actions. */
object JarvisBrain {
    enum class Action { SCREEN, HOME, SETTINGS, YOUTUBE, ROBLOX, OPEN_APP, SECURITY, STOP, GREETING, TIME, BATTERY, HELP, UNKNOWN }
    data class Result(val action: Action, val reply: String, val target: String = "")

    fun parse(raw: String): Result {
        val c = normalize(raw)
        if (c.isBlank()) return Result(Action.UNKNOWN, "ผมไม่ได้ยินคำสั่งครับ")

        if (hasAny(c, "สวัสดี", "หวัดดี", "ฮัลโหล", "hello", "hi", "เฮ้") && c.length <= 40)
            return Result(Action.GREETING, "สวัสดีครับ มีอะไรให้ผมช่วยไหมครับ")
        if (hasAny(c, "กี่โมง", "เวลาเท่าไหร่", "เวลาอะไร"))
            return Result(Action.TIME, "ตอนนี้เวลา ${java.text.SimpleDateFormat("HH:mm", Locale("th", "TH")).format(java.util.Date())} นาฬิกาครับ")
        if (hasAny(c, "แบต", "แบตเตอรี่", "แบตเหลือเท่าไหร่", "แบตเหลือกี่เปอร์เซ็นต์"))
            return Result(Action.BATTERY, "กำลังตรวจสอบแบตเตอรี่ครับ")
        if (hasAny(c, "ทำอะไรได้บ้าง", "ช่วยอะไรได้บ้าง", "ใช้งานยังไง", "วิธีใช้", "สอนใช้"))
            return Result(Action.HELP, "ผมช่วยเปิดแอป ดูหน้าจอ กลับหน้าหลัก เปิดการตั้งค่า และตรวจความปลอดภัยเบื้องต้นได้ครับ")
        if (hasAny(c, "ดูหน้าจอ", "หน้าจอนี้", "เห็นอะไรบนหน้าจอ", "อ่านหน้าจอ", "ดูจอ", "อ่านจอ"))
            return Result(Action.SCREEN, "กำลังดูหน้าจอให้ครับ")
        if (hasAny(c, "กลับหน้าหลัก", "กลับบ้าน", "หน้าหลัก", "โฮม", "กลับโฮม"))
            return Result(Action.HOME, "กำลังกลับหน้าหลักครับ")
        if (hasAny(c, "เปิดการตั้งค่า", "เปิดตั้งค่า", "เปิด settings", "เข้า settings", "ตั้งค่า"))
            return Result(Action.SETTINGS, "กำลังเปิดการตั้งค่าครับ")
        if (isYouTubeCommand(c)) return Result(Action.YOUTUBE, "กำลังเปิด YouTube ครับ", "YouTube")
        if (isRobloxCommand(c)) return Result(Action.ROBLOX, "กำลังเปิด Roblox ครับ", "Roblox")
        if (hasAny(c, "ตรวจไวรัส", "สแกนไวรัส", "ตรวจสอบไวรัส", "ตรวจความปลอดภัย", "เช็คไวรัส", "เช็คความปลอดภัย"))
            return Result(Action.SECURITY, "กำลังตรวจสอบความปลอดภัยครับ")
        if (hasAny(c, "หยุดฟัง", "ปิดโหมดฟัง", "หยุดทำงานเบื้องหลัง", "หยุดจาร์วิส", "หยุดจาวิส"))
            return Result(Action.STOP, "ปิดโหมดฟังเบื้องหลังแล้วครับ")

        val appName = extractAppName(c)
        if (appName.isNotBlank()) return Result(Action.OPEN_APP, "กำลังเปิด $appName ครับ", appName)
        return Result(Action.UNKNOWN, "ผมยังไม่เข้าใจครับ ลองบอกสิ่งที่ต้องการได้เลย")
    }

    fun stripWake(raw: String): Pair<Boolean, String> {
        val c = normalize(raw)
        val wake = listOf("hey ai", "heyai", "เฮ้เอไอ", "เฮ้ เอไอ", "จาร์วิส", "จาวิส", "จาวีส", "จาร์วีส")
        val found = wake.firstOrNull { c.contains(it) } ?: return false to c
        val command = c.substringAfter(found).trim(' ', ',', '.', '!', '?', ':', ';', '-', '_', '/', '\\')
        return true to command
    }

    fun normalize(raw: String): String {
        var s = Normalizer.normalize(raw.lowercase(Locale.ROOT), Normalizer.Form.NFKC)
        s = s.replace("\u200b", "").replace("\ufeff", "").replace(Regex("[\\p{C}]"), " ")
        s = s.replace("ยูทู๊ป", "ยูทูป").replace("ยูทู๊บ", "ยูทูบ").replace("ยู ทูป", "ยูทูป").replace("ยู ทูบ", "ยูทูบ")
            .replace("ยูทูปป์", "ยูทูป").replace("ยูทูปป", "ยูทูป")
            .replace("โรบลอก", "โรบล็อก").replace("โรบอก", "โรบล็อก")
        return s.replace(Regex("\\s+"), " ").trim()
    }

    private fun isYouTubeCommand(s: String): Boolean {
        if (!hasAny(s, "เปิด", "เข้า", "ไปที่", "ไปดู", "ดู", "เล่น")) return false
        val compact = s.replace(" ", "")
        return listOf("youtube", "ยูทูป", "ยูทูบ").any { compact.contains(it) } || fuzzyContains(compact, listOf("ยูทูป", "ยูทูบ", "youtube"))
    }

    private fun isRobloxCommand(s: String): Boolean {
        if (!hasAny(s, "เปิด", "เข้า", "ไปที่", "ไปเล่น", "เล่น")) return false
        val compact = s.replace(" ", "")
        return listOf("roblox", "โรบล็อก").any { compact.contains(it) } || fuzzyContains(compact, listOf("โรบล็อก", "roblox"))
    }

    private fun extractAppName(s: String): String {
        if (!hasAny(s, "เปิด", "เข้า", "ไปที่", "ไปยัง", "เปิดให้หน่อย", "ช่วยเปิด")) return ""
        var x = s
        listOf("ช่วยเปิด", "เปิดให้หน่อย", "เปิด", "เข้าไปที่", "เข้า", "ไปที่", "ไปยัง").forEach { x = x.replace(it, " ") }
        x = x.replace(Regex("\\bให้หน่อย\\b"), "").trim()
        if (x.length < 2 || x.length > 50) return ""
        if (listOf("youtube", "ยูทูป", "ยูทูบ", "roblox", "โรบล็อก", "settings", "ตั้งค่า").any { x.contains(it) }) return ""
        return x
    }

    private fun fuzzyContains(text: String, targets: List<String>): Boolean {
        for (target in targets) {
            val n = target.length
            if (text.length < n) continue
            for (i in 0..(text.length - n)) {
                if (levenshtein(text.substring(i, i + n), target) <= if (target.length >= 6) 2 else 1) return true
            }
        }
        return false
    }

    private fun hasAny(s: String, vararg words: String) = words.any { s.contains(it) }

    private fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        var prev = IntArray(b.length + 1) { it }
        for (i in a.indices) {
            val cur = IntArray(b.length + 1); cur[0] = i + 1
            for (j in b.indices) cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + if (a[i] == b[j]) 0 else 1)
            prev = cur
        }
        return prev[b.length]
    }
}
