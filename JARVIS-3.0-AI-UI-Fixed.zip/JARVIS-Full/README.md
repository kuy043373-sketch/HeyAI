# JARVIS 2.0

รุ่นนี้รวมแกนหลักของผู้ช่วย JARVIS ไว้ในโปรเจกต์เดียว:
- Background Foreground Service สำหรับเสียง โดยไม่เปิด Speech UI ของ Android
- Wake phrases: Hey AI / จาร์วิส
- Thai command parser พร้อมการสะกด YouTube หลายแบบและ fuzzy matching
- เปิด YouTube, Roblox, Settings, Home
- อ่านข้อความบนหน้าจอผ่าน Accessibility Service
- ตรวจความปลอดภัยแบบ heuristic สำหรับแอปที่มองเห็นได้ (ไม่อ้างว่าเป็น antivirus เต็มรูปแบบ)
- TTS ภาษาไทย และเลือกเสียงไทยที่มี metadata ว่า female ถ้ามีในเครื่อง

ข้อจำกัด: Android ไม่เปิด API hotword แบบระบบให้แอปทั่วไปได้เหมือนผู้ช่วยที่ติดมากับเครื่อง และการรู้จำเสียงแบบ offline ขึ้นกับ speech engine/รุ่นโทรศัพท์
