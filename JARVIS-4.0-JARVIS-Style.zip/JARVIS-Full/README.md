# JARVIS 4.0

JARVIS 4.0 is a personal Android assistant prototype with a JARVIS-inspired personality: calm, precise, polite, and lightly playful when appropriate.

## Voice
The default Android TTS profile is deliberately measured and low-pitched. It does not clone the movie JARVIS voice; the exact timbre depends on voices installed on the phone.

## Behaviour
- Wake phrases: “Hey AI” and “จาร์วิส”
- Background foreground-service speech recognition without launching the large speech dialog from the app
- Conservative command filtering
- Small white listening dot through Accessibility overlay
- YouTube and Roblox launching
- Accessibility screen-text reading foundation
- Short situational jokes / teasing instead of internal debug text

## Important Android limits
SpeechRecognizer is not a dedicated low-power always-on hotword engine. Android may also impose background restrictions. Screen understanding currently uses visible Accessibility text; full image understanding requires an online vision model connection.
