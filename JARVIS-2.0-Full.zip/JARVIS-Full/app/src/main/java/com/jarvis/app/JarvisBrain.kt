package com.jarvis.app

import java.text.Normalizer
import java.util.Locale

/** Local command parser. It intentionally uses simple, deterministic rules so core phone actions work offline. */
object JarvisBrain {
    enum class Action { SCREEN, HOME, SETTINGS, YOUTUBE, ROBLOX, SECURITY, STOP, UNKNOWN }

    data class Result(val action: Action, val reply: String)

    fun parse(raw: String): Result {
        val c = normalize(raw)
        return when {
            hasAny(c, "ดูหน้าจอ", "หน้าจอนี้", "เห็นอะไรบนหน้าจอ", "อ่านหน้าจอ") -> Result(Action.SCREEN, "กำลังดูหน้าจอให้ครับ")
            hasAny(c, "กลับหน้าหลัก", "กลับบ้าน", "หน้าหลัก", "โฮม") -> Result(Action.HOME, "กลับหน้าหลักแล้วครับ")
            hasAny(c, "เปิดการตั้งค่า", "เปิดตั้งค่า", "เปิด settings", "เข้า settings") -> Result(Action.SETTINGS, "เปิดการตั้งค่าแล้วครับ")
            hasAny(c, "เปิด youtube", "เปิดยูทูป", "เปิดยูทูบ", "เปิดยูทู๊ป", "เปิดยูทู๊บ") || fuzzyYouTube(c) -> Result(Action.YOUTUBE, "เปิด YouTube ให้แล้วครับ")
            hasAny(c, "เปิด roblox", "เข้า roblox", "เปิดโรบล็อก", "เปิดโรบอก") -> Result(Action.ROBLOX, "เปิด Roblox ให้แล้วครับ")
            hasAny(c, "ตรวจไวรัส", "สแกนไวรัส", "ตรวจสอบไวรัส", "ตรวจความปลอดภัย", "เช็คไวรัส", "เช็คความปลอดภัย") -> Result(Action.SECURITY, "กำลังตรวจสอบความปลอดภัยของแอปที่มองเห็นได้ครับ")
            hasAny(c, "หยุดฟัง", "ปิดโหมดฟัง", "หยุดทำงานเบื้องหลัง") -> Result(Action.STOP, "ปิดโหมดฟังเบื้องหลังแล้วครับ")
            else -> Result(Action.UNKNOWN, "ผมยังไม่เข้าใจคำสั่งนี้ครับ")
        }
    }

    fun stripWake(raw: String): Pair<Boolean, String> {
        val c = normalize(raw)
        val wakes = listOf("hey ai", "heyai", "จาร์วิส", "จาวิส", "จาวิส")
        val found = wakes.firstOrNull { c.contains(it) }
        if (found == null) return false to raw.trim()
        return true to c.substringAfter(found).trim()
    }

    fun normalize(raw: String): String {
        return Normalizer.normalize(raw.lowercase(Locale.ROOT), Normalizer.Form.NFKC)
            .replace("\u200b", "")
            .replace(Regex("[\\p{C}]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun hasAny(s: String, vararg words: String) = words.any { s.contains(it) }

    // Handles common speech-recognition distortions of "YouTube" without treating arbitrary garbage as YouTube.
    private fun fuzzyYouTube(s: String): Boolean {
        if (!s.contains("เปิด")) return false
        val tokens = s.split(' ', ' ', '/', '_', '-', '.').filter { it.isNotBlank() }
        return tokens.any { token ->
            val t = token.replace("ยู", "ยู").replace("ทูบ", "ยูทูบ")
            t == "ยูทูบ" || t == "ยูทูป" || levenshtein(t, "youtube") <= 2 || levenshtein(t, "ยูทูป") <= 1
        }
    }

    private fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        for (i in a.indices) {
            val cur = IntArray(b.length + 1)
            cur[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            prev = cur
        }
        return prev[b.length]
    }
}
