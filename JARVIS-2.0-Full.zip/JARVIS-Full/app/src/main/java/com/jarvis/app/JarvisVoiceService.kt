package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Foreground voice service. No speech-recognition UI is launched by JARVIS. */
class JarvisVoiceService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var listening = false
    private var stopping = false
    private var waitingForCommand = false
    private var restartAttempts = 0
    private val handler = Handler()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        tts = TextToSpeech(this, this)
        setupRecognizer()
    }

    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateStatus("เครื่องนี้ไม่มีระบบรับเสียง")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
        startListeningSoon(300)
    }

    private fun startListeningSoon(delay: Long = 500) {
        if (stopping) return
        handler.postDelayed({ startListening() }, delay)
    }

    private fun startListening() {
        if (stopping || listening || recognizer == null) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "th-TH")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        try {
            listening = true
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            listening = false
            startListeningSoon(1500)
        }
    }

    override fun onReadyForSpeech(params: Bundle?) {
        restartAttempts = 0
        updateStatus(if (waitingForCommand) "JARVIS กำลังรอฟังคำสั่ง" else "JARVIS กำลังรอคำว่า Hey AI หรือ จาร์วิส")
    }
    override fun onBeginningOfSpeech() = Unit
    override fun onRmsChanged(rmsdB: Float) = Unit
    override fun onBufferReceived(buffer: ByteArray?) = Unit
    override fun onEndOfSpeech() { listening = false }

    override fun onError(error: Int) {
        listening = false
        if (stopping) return
        restartAttempts = (restartAttempts + 1).coerceAtMost(8)
        val delay = when (error) {
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 2500L
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> 5000L
            else -> 700L + restartAttempts * 250L
        }
        startListeningSoon(delay)
    }

    override fun onResults(results: Bundle?) {
        listening = false
        val choices = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        val text = choices.firstOrNull()?.trim().orEmpty()
        if (text.isNotEmpty()) handleSpeech(text) else startListeningSoon(300)
    }

    override fun onPartialResults(partialResults: Bundle?) = Unit
    override fun onEvent(eventType: Int, params: Bundle?) = Unit

    private fun handleSpeech(raw: String) {
        val (wakeFound, afterWake) = JarvisBrain.stripWake(raw)

        if (wakeFound) {
            val commandText = afterWake.trim()
            if (commandText.isBlank()) {
                waitingForCommand = true
                speakAndResume("ครับ มีอะไรให้ช่วยไหม")
                return
            }
            waitingForCommand = false
            executeCommand(commandText)
            return
        }

        if (waitingForCommand) {
            waitingForCommand = false
            executeCommand(raw)
        } else {
            // Ignore ordinary speech while in wake-word mode to prevent accidental actions.
            startListeningSoon(250)
        }
    }

    private fun executeCommand(command: String) {
        val parsed = JarvisBrain.parse(command)
        updateStatus("คำสั่ง: $command")
        when (parsed.action) {
            JarvisBrain.Action.SCREEN -> {
                val text = HeyAccessibilityService.current?.readVisibleText() ?: "ยังไม่ได้เปิดสิทธิ์อ่านหน้าจอครับ"
                speakAndResume(if (text.length > 500) text.take(500) else text)
            }
            JarvisBrain.Action.HOME -> { openHome(); speakAndResume(parsed.reply) }
            JarvisBrain.Action.SETTINGS -> { openSettings(); speakAndResume(parsed.reply) }
            JarvisBrain.Action.YOUTUBE -> openApp("com.google.android.youtube", "YouTube")
            JarvisBrain.Action.ROBLOX -> openApp("com.roblox.client", "Roblox")
            JarvisBrain.Action.SECURITY -> scanSecurity()
            JarvisBrain.Action.STOP -> { speak("ปิดโหมดฟังเบื้องหลังแล้วครับ"); stopSelf() }
            JarvisBrain.Action.UNKNOWN -> speakAndResume("ผมยังไม่เข้าใจครับ ลองพูดว่า เปิด YouTube, ดูหน้าจอ หรือ ตรวจความปลอดภัย")
        }
    }

    private fun openApp(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch == null) { speakAndResume("ยังไม่พบแอป $label ในเครื่องครับ"); return }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(launch)
            speakAndResume("เปิด $label แล้วครับ")
        } catch (_: Exception) {
            speakAndResume("ผมเปิด $label ไม่ได้ครับ ลองเปิดจากหน้าแอปก่อน")
        }
    }

    private fun openSettings() {
        try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Exception) { }
    }

    private fun openHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun scanSecurity() {
        Thread {
            val findings = JarvisSecurityScanner.scan(packageManager)
            val reply = if (findings.isEmpty()) {
                "ตรวจเบื้องต้นแล้วครับ ยังไม่พบแอปที่เข้าเกณฑ์น่าสงสัย แต่ผมไม่สามารถยืนยันว่าเครื่องปลอดไวรัสได้ 100 เปอร์เซ็นต์"
            } else {
                "พบแอปที่ควรตรวจสอบเพิ่มเติม ${findings.size} รายการครับ แนะนำให้เปิด Play Protect เพื่อตรวจต่อ"
            }
            speakAndResume(reply)
        }.start()
    }

    private fun speakAndResume(text: String) {
        updateStatus(text)
        if (!ttsReady) { startListeningSoon(700); return }
        try {
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit
                override fun onDone(utteranceId: String?) { startListeningSoon(350) }
                override fun onError(utteranceId: String?) { startListeningSoon(350) }
            })
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_answer")
        } catch (_: Exception) { startListeningSoon(600) }
    }

    private fun speak(text: String) { if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_stop") }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("th", "TH"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            val female = tts.voices?.firstOrNull { v -> v.locale.language == "th" && v.name.lowercase(Locale.ROOT).contains("female") }
            if (female != null) tts.voice = female
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopping = false
        if (recognizer == null) setupRecognizer()
        return START_STICKY
    }

    override fun onDestroy() {
        stopping = true
        waitingForCommand = false
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.cancel() } catch (_: Exception) {}
        recognizer?.destroy()
        recognizer = null
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun updateStatus(text: String) {
        MainActivity.instance?.runOnUiThread { MainActivity.instance?.setBackgroundStatus(text) }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "JARVIS เบื้องหลัง", NotificationManager.IMPORTANCE_LOW)
                .apply { description = "JARVIS ใช้ไมโครโฟนเพื่อรอคำปลุก" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("JARVIS ทำงานเบื้องหลัง")
                .setContentText("รอ Hey AI หรือ จาร์วิส")
                .setContentIntent(open)
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("JARVIS ทำงานเบื้องหลัง")
                .setContentText("รอ Hey AI หรือ จาร์วิส")
                .setContentIntent(open)
                .setOngoing(true)
                .build()
        }
    }

    companion object { const val CHANNEL_ID = "jarvis_background"; const val NOTIFICATION_ID = 4201 }
}
