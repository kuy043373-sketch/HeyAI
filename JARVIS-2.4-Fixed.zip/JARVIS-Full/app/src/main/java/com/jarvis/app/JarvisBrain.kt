package com.jarvis.app

import java.text.Normalizer
import java.util.Locale

/** Command parser: conservative by design, so random ASR garbage is not executed. */
object JarvisBrain {
    enum class Action { SCREEN, HOME, SETTINGS, YOUTUBE, ROBLOX, SECURITY, STOP, UNKNOWN }
    data class Result(val action: Action, val reply: String)

    fun parse(raw: String): Result {
        val c = normalize(raw)
        if (c.isBlank()) return Result(Action.UNKNOWN, "")

        return when {
            hasAny(c, "ดูหน้าจอ", "หน้าจอนี้", "เห็นอะไรบนหน้าจอ", "อ่านหน้าจอ", "ดูจอ", "อ่านจอ") ->
                Result(Action.SCREEN, "กำลังดูหน้าจอให้ครับ")
            hasAny(c, "กลับหน้าหลัก", "กลับบ้าน", "หน้าหลัก", "โฮม", "กลับโฮม") ->
                Result(Action.HOME, "กลับหน้าหลักแล้วครับ")
            hasAny(c, "เปิดการตั้งค่า", "เปิดตั้งค่า", "เปิด settings", "เข้า settings", "ตั้งค่า") ->
                Result(Action.SETTINGS, "เปิดการตั้งค่าแล้วครับ")
            isYouTubeCommand(c) -> Result(Action.YOUTUBE, "เปิด YouTube ให้แล้วครับ")
            isRobloxCommand(c) -> Result(Action.ROBLOX, "เปิด Roblox ให้แล้วครับ")
            hasAny(c, "ตรวจไวรัส", "สแกนไวรัส", "ตรวจสอบไวรัส", "ตรวจความปลอดภัย", "เช็คไวรัส", "เช็คความปลอดภัย") ->
                Result(Action.SECURITY, "กำลังตรวจสอบความปลอดภัยของแอปที่มองเห็นได้ครับ")
            hasAny(c, "หยุดฟัง", "ปิดโหมดฟัง", "หยุดทำงานเบื้องหลัง", "หยุดจาร์วิส", "หยุดจาวิส") ->
                Result(Action.STOP, "ปิดโหมดฟังเบื้องหลังแล้วครับ")
            else -> Result(Action.UNKNOWN, "ผมยังไม่เข้าใจคำสั่งนี้ครับ")
        }
    }

    /** Returns whether a wake phrase was detected and the remaining command. */
    fun stripWake(raw: String): Pair<Boolean, String> {
        val c = normalize(raw)
        val wake = listOf("hey ai", "heyai", "เฮ้เอไอ", "เฮ้ เอไอ", "จาร์วิส", "จาวิส", "จาวีส", "จาร์วีส")
        val found = wake.firstOrNull { c.contains(it) } ?: return false to c
        val command = c.substringAfter(found)
            .trim(' ', ',', '.', '!', '?', ':', ';', '-', '_', '/', '\\')
        return true to command
    }

    fun normalize(raw: String): String {
        var s = Normalizer.normalize(raw.lowercase(Locale.ROOT), Normalizer.Form.NFKC)
        s = s.replace("\u200b", "").replace("\ufeff", "")
        s = s.replace(Regex("[\\p{C}]"), " ")
        // Common Thai ASR variations. Do not aggressively rewrite arbitrary text.
        s = s.replace("ยูทู๊ป", "ยูทูป")
            .replace("ยูทู๊บ", "ยูทูบ")
            .replace("ยู ทูป", "ยูทูป")
            .replace("ยู ทูบ", "ยูทูบ")
            .replace("ยูทูปป์", "ยูทูป")
            .replace("ยูทูปป", "ยูทูป")
            .replace("โรบลอก", "โรบล็อก")
            .replace("โรบอก", "โรบล็อก")
        return s.replace(Regex("\\s+"), " ").trim()
    }

    private fun isYouTubeCommand(s: String): Boolean {
        val hasOpen = hasAny(s, "เปิด", "เข้า", "ไปที่", "ไปดู", "ดู")
        if (!hasOpen) return false
        val compact = s.replace(" ", "")
        return listOf("youtube", "ยูทูป", "ยูทูบ", "ยูทู๊ป", "ยูทู๊บ").any { compact.contains(it.replace(" ", "")) }
                || fuzzyContains(compact, listOf("ยูทูป", "ยูทูบ", "youtube"))
    }

    private fun isRobloxCommand(s: String): Boolean {
        if (!hasAny(s, "เปิด", "เข้า", "ไปที่", "ไปเล่น", "เล่น")) return false
        val compact = s.replace(" ", "")
        return listOf("roblox", "โรบล็อก", "โรบลอก", "โรบอก").any { compact.contains(it.replace(" ", "")) }
                || fuzzyContains(compact, listOf("โรบล็อก", "roblox"))
    }

    private fun fuzzyContains(text: String, targets: List<String>): Boolean {
        // Compare short windows so an ASR typo does not have to be one whitespace token.
        for (target in targets) {
            val n = target.length
            if (text.length < n) continue
            for (i in 0..(text.length - n)) {
                if (levenshtein(text.substring(i, i + n), target) <= if (target.length >= 6) 2 else 1) return true
            }
        }
        return false
    }

    private fun hasAny(s: String, vararg words: String) = words.any { s.contains(it) }

    private fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        for (i in a.indices) {
            val cur = IntArray(b.length + 1)
            cur[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            prev = cur
        }
        return prev[b.length]
    }
}
