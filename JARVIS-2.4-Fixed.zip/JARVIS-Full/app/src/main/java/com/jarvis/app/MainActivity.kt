package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var answer: TextView
    private lateinit var tts: TextToSpeech
    private val voiceRequest = 7001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
        tts = TextToSpeech(this, this)
        showCosmicSplash()
    }

    private fun showCosmicSplash() {
        val splash = android.widget.ImageView(this).apply {
            setImageResource(com.jarvis.app.R.drawable.jarvis_splash)
            scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(android.graphics.Color.rgb(18, 5, 31))
        }
        setContentView(splash)
        Handler(Looper.getMainLooper()).postDelayed({
            buildUi()
            requestNeededPermissions()
        }, 2200)
    }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) permissions += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) permissions += Manifest.permission.POST_NOTIFICATIONS
        if (permissions.isNotEmpty()) requestPermissions(permissions.toTypedArray(), 9001)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(28, 28, 28, 20) }
        val title = TextView(this).apply { text = "🤖 JARVIS 2.4"; textSize = 30f; gravity = Gravity.CENTER; setPadding(0, 10, 0, 12) }
        status = TextView(this).apply { text = "พร้อมทำงาน"; textSize = 17f; setPadding(0, 0, 0, 12) }
        val background = Button(this).apply { text = "🎙️ เปิด JARVIS เบื้องหลัง"; setOnClickListener { startBackgroundListening() } }
        val stop = Button(this).apply { text = "⏹️ หยุด JARVIS เบื้องหลัง"; setOnClickListener { stopBackgroundListening() } }
        val listen = Button(this).apply { text = "🎤 พูดกับ JARVIS"; setOnClickListener { listen() } }
        val read = Button(this).apply { text = "👁️ ดูหน้าจอนี้"; setOnClickListener { readScreen(true) } }
        val security = Button(this).apply { text = "🛡️ ตรวจความปลอดภัย"; setOnClickListener { runSecurityScan(true) } }
        val access = Button(this).apply { text = "⚙️ เปิดสิทธิ์อ่านหน้าจอ"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        answer = TextView(this).apply { text = "JARVIS พร้อมรับคำสั่ง"; textSize = 17f; setPadding(0, 14, 0, 14) }
        root.addView(title); root.addView(status); root.addView(background); root.addView(stop); root.addView(listen); root.addView(read); root.addView(security); root.addView(access); root.addView(answer, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun startBackgroundListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 9001); return }
        val intent = Intent(this, JarvisVoiceService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            status.text = "🟢 JARVIS ทำงานเบื้องหลังแล้ว"
            answer.text = "ปิดหน้าแอปได้ แล้วพูดว่า “Hey AI” หรือ “จาร์วิส”"
        } catch (e: Exception) { status.text = "เริ่มเบื้องหลังไม่สำเร็จ"; answer.text = e.message ?: "เกิดข้อผิดพลาด" }
    }

    private fun stopBackgroundListening() { stopService(Intent(this, JarvisVoiceService::class.java)); status.text = "⏹️ หยุด JARVIS แล้ว"; answer.text = "โหมดเบื้องหลังถูกปิด" }

    fun setBackgroundStatus(text: String) { if (::status.isInitialized) status.text = "🟢 $text"; if (::answer.isInitialized) answer.text = text }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "th-TH")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "พูดคำสั่งกับ JARVIS")
        }
        try { startActivityForResult(i, voiceRequest) } catch (_: Exception) { speak("เครื่องนี้ไม่มีระบบรับเสียง") }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequest && resultCode == RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.trim().orEmpty()
            execute(JarvisBrain.parse(JarvisBrain.stripWake(text).second))
        }
    }

    private fun execute(result: JarvisBrain.Result) {
        status.text = when (result.action) {
            JarvisBrain.Action.YOUTUBE -> "กำลังเปิด YouTube…"
            JarvisBrain.Action.ROBLOX -> "กำลังเปิด Roblox…"
            JarvisBrain.Action.SETTINGS -> "กำลังเปิดการตั้งค่า…"
            JarvisBrain.Action.HOME -> "กำลังกลับหน้าหลัก…"
            else -> result.reply
        }
        when (result.action) {
            JarvisBrain.Action.SCREEN -> readScreen(true)
            JarvisBrain.Action.HOME -> { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)); respond(result.reply) }
            JarvisBrain.Action.SETTINGS -> { startActivity(Intent(Settings.ACTION_SETTINGS)); respond(result.reply) }
            JarvisBrain.Action.YOUTUBE -> openApp("com.google.android.youtube", "YouTube")
            JarvisBrain.Action.ROBLOX -> openApp("com.roblox.client", "Roblox")
            JarvisBrain.Action.SECURITY -> runSecurityScan(true)
            JarvisBrain.Action.STOP -> stopBackgroundListening()
            JarvisBrain.Action.UNKNOWN -> respond("ผมยังไม่เข้าใจคำสั่งนี้ครับ ลองพูดว่า เปิด YouTube, ดูหน้าจอ หรือ ตรวจความปลอดภัย")
        }
    }

    private fun openApp(packageName: String, label: String) {
        val direct = packageManager.getLaunchIntentForPackage(packageName)
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val launcherApps = packageManager.queryIntentActivities(launcherIntent, 0)
        val queried = launcherApps.firstOrNull { it.activityInfo.packageName == packageName }
            ?.let { Intent(launcherIntent).setClassName(it.activityInfo.packageName, it.activityInfo.name) }
        val byLabel = launcherApps.firstOrNull { info ->
            packageManager.getApplicationLabel(info.activityInfo.applicationInfo).toString().equals(label, true)
        }?.let { Intent(launcherIntent).setClassName(it.activityInfo.packageName, it.activityInfo.name) }
        val launch = direct ?: queried ?: byLabel
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            try { startActivity(launch); respond("กำลังเปิด $label…") }
            catch (_: Exception) { respond("เปิด $label ไม่สำเร็จครับ") }
        } else respond("ไม่พบแอป $label ในเครื่องครับ")
    }

    private fun respond(text: String) { answer.text = text; speak(text) }

    fun readScreen(speakResult: Boolean = false) {
        val text = HeyAccessibilityService.current?.readVisibleText() ?: "ยังไม่ได้เปิดสิทธิ์อ่านหน้าจอครับ"
        answer.text = text
        if (speakResult) speak(if (text.length > 500) text.take(500) else text)
    }

    private fun runSecurityScan(speakResult: Boolean) {
        Thread {
            val findings = JarvisSecurityScanner.scan(packageManager)
            val text = if (findings.isEmpty()) {
                "ไม่พบแอปที่เข้าเกณฑ์น่าสงสัยจากการตรวจแบบพื้นฐานครับ แต่ JARVIS ไม่สามารถยืนยันว่าเครื่องปลอดมัลแวร์ได้ 100%"
            } else {
                "พบ ${findings.size} แอปที่ควรตรวจสอบเพิ่มเติม:\n" + findings.take(5).joinToString("\n") { "• ${it.label}: ${it.reasons.joinToString(", ")}" } + "\n\nแนะนำให้ตรวจด้วย Play Protect ด้วยครับ"
            }
            runOnUiThread { answer.text = text; status.text = if (findings.isEmpty()) "🟢 ตรวจเบื้องต้นแล้ว" else "🟠 พบสิ่งที่ควรตรวจสอบ"; if (speakResult) speak(if (findings.isEmpty()) "ยังไม่พบสัญญาณน่าสงสัยจากการตรวจเบื้องต้นครับ" else "พบแอปที่ควรตรวจสอบเพิ่มเติมครับ") }
        }.start()
    }

    private fun speak(text: String) { if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis") }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("th", "TH")
            val female = tts.voices?.firstOrNull { it.locale.language == "th" && it.name.lowercase(Locale.ROOT).contains("female") }
            if (female != null) tts.voice = female
        }
    }

    override fun onDestroy() { if (::tts.isInitialized) tts.shutdown(); instance = null; super.onDestroy() }
    companion object { var instance: MainActivity? = null }
}
