package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class HeyAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        current = this
        MainActivity.instance?.refreshScreenSummary()
    }

    override fun onInterrupt() = Unit

    override fun onServiceConnected() {
        super.onServiceConnected()
        current = this
        MainActivity.instance?.refreshScreenSummary()
    }

    fun readVisibleText(): String {
        val root = rootInActiveWindow ?: return "ยังอ่านหน้าจอไม่ได้"
        val out = StringBuilder()
        collect(root, out)
        root.recycle()
        return out.toString().trim().ifEmpty { "ไม่พบข้อความหรือองค์ประกอบที่อ่านได้บนหน้าจอ" }
    }

    private fun collect(node: AccessibilityNodeInfo, out: StringBuilder) {
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) out.append(text).append('\n')
        else if (desc.isNotEmpty()) out.append(desc).append('\n')
        for (i in 0 until node.childCount) node.getChild(i)?.let { child -> collect(child, out); child.recycle() }
    }

    override fun onDestroy() {
        if (current === this) current = null
        super.onDestroy()
    }

    companion object { var current: HeyAccessibilityService? = null }
}
