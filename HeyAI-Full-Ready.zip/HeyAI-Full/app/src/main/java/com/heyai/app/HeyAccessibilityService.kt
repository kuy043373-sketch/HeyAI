package com.heyai.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class HeyAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { MainActivity.instance?.refreshScreenSummary() }
    override fun onInterrupt() {}

    fun readVisibleText(): String {
        val root = rootInActiveWindow ?: return "ยังอ่านหน้าจอไม่ได้\nกรุณาเปิดสิทธิ์การช่วยเหลือพิเศษให้ Hey AI"
        val out = StringBuilder()
        collect(root, out)
        return out.toString().trim().take(8000).ifBlank { "ไม่พบข้อความที่อ่านได้บนหน้าจอนี้" }
    }

    private fun collect(node: AccessibilityNodeInfo?, out: StringBuilder) {
        if (node == null) return
        val t = node.text?.toString()?.trim()
        val d = node.contentDescription?.toString()?.trim()
        if (!t.isNullOrEmpty()) out.append(t).append('\n')
        else if (!d.isNullOrEmpty()) out.append(d).append('\n')
        for (i in 0 until node.childCount) collect(node.getChild(i), out)
    }

    companion object { var current: HeyAccessibilityService? = null }
    override fun onServiceConnected() { super.onServiceConnected(); current = this; MainActivity.instance?.refreshScreenSummary() }
    override fun onDestroy() { current = null; super.onDestroy() }
}
