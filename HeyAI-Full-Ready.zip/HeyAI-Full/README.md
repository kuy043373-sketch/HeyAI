# Hey AI 1.0.0 — รุ่นพร้อมสร้าง APK ติดตั้ง

## ทำได้แล้ว
- แอป Android ชื่อ Hey AI
- ปุ่มรับเสียงภาษาไทย
- คำสั่ง “ดูหน้าจอนี้”
- อ่านข้อความ/คำอธิบายจากหน้าจอด้วย Accessibility Service
- ตอบกลับด้วยเสียงภาษาไทย (Text-to-Speech)
- เปิด Settings / กลับหน้าหลักด้วยเสียง
- หน้าแอปสำหรับเปิดสิทธิ์อ่านหน้าจอ

## วิธีสร้าง APK
1. เปิดโฟลเดอร์นี้ด้วย Android Studio รุ่นที่รองรับ Android Gradle Plugin 8.7.x
2. กด Sync Project with Gradle Files
3. รอ dependencies ดาวน์โหลดครบ
4. เลือก Build > Build APK(s)
5. APK debug จะอยู่ที่ `app/build/outputs/apk/debug/app-debug.apk`
6. ส่ง APK ไปที่มือถือ Android แล้วติดตั้ง

## หลังติดตั้ง
1. เปิด Hey AI
2. อนุญาตไมโครโฟน
3. กด “เปิดสิทธิ์อ่านหน้าจอ”
4. เปิด Hey AI ใน Accessibility
5. กลับแอป แล้วกด “ดูหน้าจอนี้” หรือ “พูดกับ Hey AI”

หมายเหตุ: wake word แบบฟัง “Hey AI” ตลอดเวลา และ AI Vision จากภาพหน้าจอจริงยังต้องเพิ่มโมดูล/บริการเฉพาะต่อจากฐานนี้
