package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var answer: TextView
    private lateinit var tts: TextToSpeech
    private val voiceRequest = 7001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
        tts = TextToSpeech(this, this)
        buildUi()
        requestNeededPermissions()
    }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissions += Manifest.permission.RECORD_AUDIO
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissions += Manifest.permission.POST_NOTIFICATIONS
        }
        if (permissions.isNotEmpty()) requestPermissions(permissions.toTypedArray(), 9001)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 28, 28, 20)
        }
        val title = TextView(this).apply { text = "🤖 JARVIS"; textSize = 30f; gravity = Gravity.CENTER; setPadding(0, 10, 0, 12) }
        status = TextView(this).apply { text = "พร้อมทำงาน • เปิดโหมดเบื้องหลังได้"; textSize = 17f; setPadding(0, 0, 0, 12) }
        val background = Button(this).apply {
            text = "🎙️ เปิดโหมดฟังเบื้องหลัง"
            setOnClickListener { startBackgroundListening() }
        }
        val stop = Button(this).apply {
            text = "⏹️ หยุดโหมดฟังเบื้องหลัง"
            setOnClickListener { stopBackgroundListening() }
        }
        val listen = Button(this).apply { text = "🎤 พูดกับ JARVIS ตอนนี้"; setOnClickListener { listen() } }
        val read = Button(this).apply { text = "👁️ ดูหน้าจอนี้"; setOnClickListener { readScreen(true) } }
        val access = Button(this).apply { text = "⚙️ เปิดสิทธิ์อ่านหน้าจอ"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        answer = TextView(this).apply { text = "คำตอบของ JARVIS จะแสดงตรงนี้"; textSize = 17f; setPadding(0, 14, 0, 14) }
        root.addView(title); root.addView(status); root.addView(background); root.addView(stop); root.addView(listen); root.addView(read); root.addView(access); root.addView(answer, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun startBackgroundListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 9001)
            return
        }
        try {
            val intent = Intent(this, JarvisVoiceService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            status.text = "🟢 JARVIS ทำงานเบื้องหลังแล้ว • พูดว่า Hey AI"
            answer.text = "ตอนนี้ปิดหน้าแอปได้ แล้วลองพูดว่า “Hey AI เปิด YouTube”"
        } catch (e: Exception) {
            status.text = "เริ่มโหมดเบื้องหลังไม่สำเร็จ"
            answer.text = e.message ?: "เกิดข้อผิดพลาด"
        }
    }

    private fun stopBackgroundListening() {
        stopService(Intent(this, JarvisVoiceService::class.java))
        status.text = "⏹️ หยุดโหมดฟังเบื้องหลังแล้ว"
        answer.text = "ถ้าต้องการใช้อีกครั้ง กดเปิดโหมดฟังเบื้องหลัง"
    }

    fun setBackgroundStatus(text: String) {
        status.text = "🟢 $text"
        answer.text = text
    }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "พูดคำสั่งกับ JARVIS")
        }
        try { startActivityForResult(i, voiceRequest) } catch (_: Exception) { speak("เครื่องนี้ไม่มีระบบรับเสียง") }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != voiceRequest || resultCode != RESULT_OK) return
        val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.trim().orEmpty()
        handleCommand(text)
    }

    private fun handleCommand(command: String) {
        val normalized = command.lowercase(Locale.getDefault())
            .replace("hey ai", "")
            .replace("heyai", "")
            .replace("จาร์วิส", "")
            .replace("จาวิส", "")
            .replace("jarvis", "")
            .trim()
        status.text = "คำสั่ง: $command"
        when {
            normalized.contains("ดูหน้าจอ") || normalized.contains("หน้าจอนี้") || normalized.contains("เห็นอะไร") -> readScreen(true)
            normalized.contains("กลับหน้าหลัก") || normalized == "หน้าหลัก" -> { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)); respond("กลับหน้าหลักแล้ว") }
            normalized.contains("เปิดการตั้งค่า") || normalized.contains("เปิด settings") || normalized.contains("เปิดตั้งค่า") -> { startActivity(Intent(Settings.ACTION_SETTINGS)); respond("เปิดการตั้งค่าแล้ว") }
            normalized.contains("เปิด youtube") || normalized.contains("เปิดยูทูป") -> openApp("com.google.android.youtube", "YouTube")
            normalized.contains("เปิด roblox") -> openApp("com.roblox.client", "Roblox")
            normalized.contains("เปิด") -> respond("ตอนนี้รองรับการเปิด YouTube, Roblox และการตั้งค่า")
            else -> respond("ตอนนี้ JARVIS ใช้คำสั่งพื้นฐานแบบ Offline ได้")
        }
    }

    private fun openApp(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) { startActivity(launch); respond("เปิด$labelแล้ว") }
        else respond("ยังไม่พบแอป$labelในเครื่อง")
    }

    private fun respond(text: String) { answer.text = text; speak(text) }

    fun readScreen(speakResult: Boolean = false) {
        val text = HeyAccessibilityService.current?.readVisibleText() ?: "ยังไม่ได้เปิดสิทธิ์อ่านหน้าจอ"
        answer.text = text
        if (speakResult) speak(if (text.length > 400) text.take(400) else text)
    }

    fun refreshScreenSummary() {
        if (::answer.isInitialized) runOnUiThread { answer.text = HeyAccessibilityService.current?.readVisibleText() ?: "ยังไม่ได้เปิดสิทธิ์อ่านหน้าจอ" }
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("th", "TH")
            val voices = tts.voices ?: emptySet()
            val female = voices.firstOrNull { v -> v.locale.language == "th" && v.name.lowercase(Locale.ROOT).contains("female") }
            if (female != null) tts.voice = female
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        instance = null
        super.onDestroy()
    }

    companion object { var instance: MainActivity? = null }
}
