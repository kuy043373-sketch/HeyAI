package com.jarvis.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Background voice layer for JARVIS.
 *
 * Android does not expose a general always-on hotword API to ordinary apps,
 * so this service keeps the system speech recognizer active while JARVIS is
 * enabled. It listens for "Hey AI" / "จาร์วิส", then handles a command.
 * The user must start this foreground microphone service once from the app.
 */
class JarvisVoiceService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var listening = false
    private var stopping = false
    private var waitingForCommand = false
    private var restartAttempts = 0

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        tts = TextToSpeech(this, this)
        setupRecognizer()
    }

    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateStatus("เครื่องนี้ไม่มีระบบรับเสียง")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(this)
        }
        startListeningSoon(250)
    }

    private fun startListeningSoon(delay: Long = 500) {
        if (stopping) return
        android.os.Handler(mainLooper).postDelayed({ startListening() }, delay)
    }

    private fun startListening() {
        if (stopping || listening || recognizer == null) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "th-TH")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            // Prefer an on-device/offline recognizer when the installed engine supports it.
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        try {
            listening = true
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            listening = false
            startListeningSoon(1500)
        }
    }

    override fun onReadyForSpeech(params: Bundle?) {
        restartAttempts = 0
        updateStatus(if (waitingForCommand) "JARVIS กำลังรอฟังคำสั่ง" else "JARVIS กำลังรอคำว่า Hey AI")
    }

    override fun onBeginningOfSpeech() = Unit
    override fun onRmsChanged(rmsdB: Float) = Unit
    override fun onBufferReceived(buffer: ByteArray?) = Unit

    override fun onEndOfSpeech() {
        listening = false
    }

    override fun onError(error: Int) {
        listening = false
        if (stopping) return
        restartAttempts = (restartAttempts + 1).coerceAtMost(6)
        // Speech services can report errors while idle. Back off instead of spinning.
        val delay = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 2500L else 800L + restartAttempts * 250L
        startListeningSoon(delay)
    }

    override fun onResults(results: Bundle?) {
        listening = false
        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull()?.trim().orEmpty()
        if (text.isNotEmpty()) handleSpeech(text)
        else startListeningSoon(350)
    }

    override fun onPartialResults(partialResults: Bundle?) {
        // We intentionally act on final results to reduce accidental commands.
    }

    override fun onEvent(eventType: Int, params: Bundle?) = Unit

    private fun handleSpeech(raw: String) {
        val normalized = raw.lowercase(Locale.getDefault())
            .replace("hey ai", "hey ai ")
            .replace("heyai", "hey ai ")
            .replace("จาร์วิส", "จาร์วิส ")
            .replace("จาวิส", "จาร์วิส ")
            .replace("jarvis", "jarvis ")
            .trim()

        val wakeIndex = listOf("hey ai", "จาร์วิส", "จาวิส", "jarvis")
            .map { normalized.indexOf(it) }
            .filter { it >= 0 }
            .minOrNull() ?: -1

        if (!waitingForCommand && wakeIndex < 0) {
            updateStatus("ได้ยิน: $raw")
            startListeningSoon(250)
            return
        }

        val command = if (waitingForCommand) {
            normalized
        } else {
            val wake = listOf("hey ai", "จาร์วิส", "จาวิส", "jarvis")
                .firstOrNull { normalized.contains(it) }
            wake?.let { normalized.substringAfter(it).trim() }.orEmpty()
        }

        waitingForCommand = false
        if (command.isBlank()) {
            speakAndResume("ครับ มีอะไรให้ช่วยไหม")
        } else {
            executeCommand(command)
        }
    }

    private fun executeCommand(command: String) {
        updateStatus("คำสั่ง: $command")
        when {
            command.contains("ดูหน้าจอ") || command.contains("หน้าจอนี้") || command.contains("เห็นอะไร") -> {
                val text = HeyAccessibilityService.current?.readVisibleText()
                    ?: "ยังไม่ได้เปิดสิทธิ์อ่านหน้าจอ"
                val answer = if (text.length > 500) text.take(500) else text
                speakAndResume(answer)
            }
            command.contains("กลับหน้าหลัก") || command == "หน้าหลัก" -> {
                openHome()
                speakAndResume("กลับหน้าหลักแล้ว")
            }
            command.contains("เปิดการตั้งค่า") || command.contains("เปิด settings") || command.contains("เปิดตั้งค่า") -> {
                openSettings()
                speakAndResume("เปิดการตั้งค่าแล้ว")
            }
            command.contains("เปิด youtube") || command.contains("เปิดยูทูป") -> {
                openApp("com.google.android.youtube", "YouTube")
            }
            command.contains("เปิด roblox") -> {
                openApp("com.roblox.client", "Roblox")
            }
            command.contains("หยุดฟัง") || command.contains("ปิดโหมดฟัง") -> {
                speak("ปิดโหมดฟังเบื้องหลังแล้ว")
                stopSelf()
            }
            command.contains("เปิด") -> speakAndResume("ตอนนี้ผมเปิดได้ YouTube, Roblox และการตั้งค่า")
            else -> speakAndResume("ผมได้ยินว่า $command แต่คำสั่งนี้ยังไม่มีในโหมดออฟไลน์")
        }
    }

    private fun openApp(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launch)
            speakAndResume("เปิด$labelแล้ว")
        } else {
            speakAndResume("ยังไม่พบแอป$labelในเครื่อง")
        }
    }

    private fun openSettings() {
        val intent = Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    private fun openHome() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    private fun speakAndResume(text: String) {
        updateStatus(text)
        if (!ttsReady) {
            startListeningSoon(500)
            return
        }
        try {
            tts.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit
                override fun onDone(utteranceId: String?) { startListeningSoon(350) }
                override fun onError(utteranceId: String?) { startListeningSoon(350) }
            })
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_bg")
        } catch (_: Exception) {
            startListeningSoon(500)
        }
    }

    private fun speak(text: String) {
        if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_bg_stop")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = tts.language.let {
                tts.language = Locale("th", "TH")
                tts.language != TextToSpeech.LANG_MISSING_DATA && tts.language != TextToSpeech.LANG_NOT_SUPPORTED
            }
            val female = tts.voices?.firstOrNull { voice ->
                voice.locale.language == "th" && voice.name.lowercase(Locale.ROOT).contains("female")
            }
            if (female != null) tts.voice = female
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopping = false
        if (recognizer == null) setupRecognizer()
        return START_STICKY
    }

    override fun onDestroy() {
        stopping = true
        listening = false
        try { recognizer?.cancel() } catch (_: Exception) {}
        recognizer?.destroy()
        recognizer = null
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun updateStatus(text: String) {
        MainActivity.instance?.runOnUiThread {
            MainActivity.instance?.setBackgroundStatus(text)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "JARVIS เบื้องหลัง",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "แจ้งว่า JARVIS กำลังรอฟังคำว่า Hey AI" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("JARVIS กำลังทำงานเบื้องหลัง")
                .setContentText("รอคำว่า Hey AI หรือ จาร์วิส")
                .setContentIntent(open)
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("JARVIS กำลังทำงานเบื้องหลัง")
                .setContentText("รอคำว่า Hey AI หรือ จาร์วิส")
                .setContentIntent(open)
                .setOngoing(true)
                .build()
        }
    }

    companion object {
        const val CHANNEL_ID = "jarvis_background"
        const val NOTIFICATION_ID = 4201
    }
}
