package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Stable foreground voice loop. It never launches the Android speech UI. */
class JarvisVoiceService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var listening = false
    private var waitingForCommand = false
    private var stopping = false
    private var speaking = false
    private var lastUserText = ""

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        tts = TextToSpeech(this, this)
        createRecognizer()
    }

    private fun createRecognizer() {
        if (stopping) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateStatus("เครื่องนี้ไม่มีระบบรับเสียง")
            return
        }
        destroyRecognizer()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(this)
        scheduleListen(700)
    }

    private fun destroyRecognizer() {
        try { recognizer?.cancel() } catch (_: Exception) {}
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        listening = false
    }

    private fun scheduleListen(delay: Long = 700) {
        if (stopping) return
        main.removeCallbacksAndMessages(null)
        main.postDelayed({ startListening() }, delay.coerceAtLeast(250L))
    }

    private fun startListening() {
        if (stopping || listening || speaking) return
        val r = recognizer ?: run { createRecognizer(); return }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "th-TH")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            // Do not force offline recognition: some phones have no offline Thai model.
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
        }
        try {
            listening = true
            HeyAccessibilityService.current?.setListeningIndicator(true)
            r.startListening(intent)
        } catch (_: Exception) {
            listening = false
            recreateAndRetry(1500)
        }
    }

    private fun recreateAndRetry(delay: Long) {
        if (stopping) return
        destroyRecognizer()
        main.removeCallbacksAndMessages(null)
        main.postDelayed({ createRecognizer() }, delay)
    }

    override fun onReadyForSpeech(params: Bundle?) {
        updateStatus(if (waitingForCommand) "JARVIS รอคำสั่ง" else "JARVIS กำลังรอ Hey AI หรือ จาร์วิส")
    }

    override fun onBeginningOfSpeech() = Unit
    override fun onRmsChanged(rmsdB: Float) = Unit
    override fun onBufferReceived(buffer: ByteArray?) = Unit
    override fun onEndOfSpeech() { listening = false }

    override fun onError(error: Int) {
        listening = false
        HeyAccessibilityService.current?.setListeningIndicator(false)
        if (stopping) return
        val delay = when (error) {
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> 5000L
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 2500L
            SpeechRecognizer.ERROR_NETWORK,
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> 1800L
            SpeechRecognizer.ERROR_CLIENT -> 1200L
            else -> 800L
        }
        recreateAndRetry(delay)
    }

    override fun onResults(results: Bundle?) {
        listening = false
        HeyAccessibilityService.current?.setListeningIndicator(false)
        val candidates = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            .orEmpty().map { it.trim() }.filter { it.isNotEmpty() }
        if (candidates.isEmpty()) {
            scheduleListen(300)
            return
        }

        // Never execute the first ASR result blindly. Pick the first candidate
        // that maps to a known action; this filters common Thai ASR garbage.
        val directCandidates = candidates.map { raw ->
            val (wake, command) = JarvisBrain.stripWake(raw)
            Triple(raw, wake, command)
        }
        val direct = directCandidates.asSequence()
            .filter { it.second && it.third.isNotBlank() }
            .mapNotNull { JarvisBrain.parse(it.third) }
            .firstOrNull { it.action != JarvisBrain.Action.UNKNOWN }
        val wakeOnly = directCandidates.any { it.second && it.third.isBlank() }

        when {
            direct != null -> {
                waitingForCommand = false
                executeParsed(direct, directCandidates.firstOrNull { it.second && it.third.isNotBlank() }?.third.orEmpty())
            }
            waitingForCommand -> {
                waitingForCommand = false
                val parsed = candidates.asSequence()
                    .map { JarvisBrain.parse(it) }
                    .firstOrNull { it.action != JarvisBrain.Action.UNKNOWN }
                if (parsed != null) executeParsed(parsed, candidates.first())
                else speakAndResume("ผมยังไม่เข้าใจครับ ลองพูดว่า เปิด YouTube หรือ ดูหน้าจอ")
            }
            wakeOnly -> {
                waitingForCommand = true
                speakAndResume("ครับ มีอะไรให้ช่วยไหม")
            }
            else -> scheduleListen(250)
        }
    }

    override fun onPartialResults(partialResults: Bundle?) = Unit
    override fun onEvent(eventType: Int, params: Bundle?) = Unit

    private fun executeParsed(parsed: JarvisBrain.Result, userText: String) {
        lastUserText = userText
        val reply = JarvisBrain.playfulReply(userText, parsed.reply)
        updateStatus(reply)
        when (parsed.action) {
            JarvisBrain.Action.SCREEN -> {
                val text = HeyAccessibilityService.current?.readVisibleText()
                    ?: "ยังไม่ได้เปิดสิทธิ์อ่านหน้าจอครับ"
                val screenReply = JarvisBrain.screenReply(text)
                speakAndResume(screenReply.take(1000))
            }
            JarvisBrain.Action.HOME -> { openHome(); speakAndResume(reply) }
            JarvisBrain.Action.BACK -> { openBack(); speakAndResume(reply) }
            JarvisBrain.Action.SETTINGS -> { openSettings(); speakAndResume(reply) }
            JarvisBrain.Action.YOUTUBE -> openAppByLabel("YouTube")
            JarvisBrain.Action.ROBLOX -> openAppByLabel("Roblox")
            JarvisBrain.Action.OPEN_APP -> openAppByLabel(parsed.target)
            JarvisBrain.Action.SECURITY -> scanSecurity()
            JarvisBrain.Action.TIME, JarvisBrain.Action.GREETING, JarvisBrain.Action.HELP, JarvisBrain.Action.CHAT -> speakAndResume(reply)
            JarvisBrain.Action.BATTERY -> speakBattery()
            JarvisBrain.Action.STOP -> { speak(reply); main.postDelayed({ stopSelf() }, 700) }
            JarvisBrain.Action.UNKNOWN -> speakAndResume(reply)
        }
    }

    private fun speakBattery() {
        val bm = getSystemService(android.content.Context.BATTERY_SERVICE) as android.os.BatteryManager
        val level = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
        speakAndResume("ตอนนี้แบตเตอรี่ประมาณ $level เปอร์เซ็นต์ครับ")
    }

    private fun openAppByLabel(label: String) {
        val preferred = when (label.lowercase(Locale.ROOT)) {
            "youtube" -> listOf("com.google.android.youtube")
            "roblox" -> listOf("com.roblox.client")
            else -> emptyList()
        }
        // Android 11+ can hide installed packages unless they are declared in <queries>.
        // Prefer the known package, then inspect actual launcher activities.
        val preferredLaunch = preferred.firstNotNullOfOrNull { packageName ->
            packageManager.getLaunchIntentForPackage(packageName)
        }

        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val launcherApps = packageManager.queryIntentActivities(launcherIntent, 0)
        val byPackage = preferred.firstNotNullOfOrNull { packageName ->
            launcherApps.firstOrNull { it.activityInfo.packageName == packageName }
                ?.let { Intent(launcherIntent).setClassName(it.activityInfo.packageName, it.activityInfo.name) }
        }
        val byLabel = launcherApps.firstOrNull { info ->
            val appInfo = info.activityInfo.applicationInfo
            val actual = packageManager.getApplicationLabel(appInfo).toString()
            actual.equals(label, true) || actual.contains(label, true) || label.contains(actual, true)
        }?.let { Intent(launcherIntent).setClassName(it.activityInfo.packageName, it.activityInfo.name) }

        val launch = preferredLaunch ?: byPackage ?: byLabel
        if (launch == null) {
            speakAndResume("ผมหาแอป $label ในเครื่องไม่เจอครับ")
            return
        }

        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            startActivity(launch)
            // Keep the user-facing response short: no internal command names.
            speakAndResume("กำลังเปิด $label ครับ")
        } catch (_: Exception) {
            speakAndResume("เปิด $label ไม่สำเร็จครับ")
        }
    }

    private fun openSettings() {
        try {
            startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) { }
    }

    private fun openHome() {
        val accessibility = HeyAccessibilityService.current
        if (accessibility != null && accessibility.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)) return
        try {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) { }
    }

    private fun openBack() {
        HeyAccessibilityService.current?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
    }

    private fun scanSecurity() {
        Thread {
            val findings = JarvisSecurityScanner.scan(packageManager)
            val reply = if (findings.isEmpty()) {
                "ตรวจเบื้องต้นแล้วครับ ยังไม่พบแอปที่เข้าเกณฑ์น่าสงสัย แต่ผมไม่สามารถยืนยันว่าเครื่องปลอดมัลแวร์ได้ 100 เปอร์เซ็นต์"
            } else {
                "พบแอปที่ควรตรวจสอบเพิ่มเติม ${findings.size} รายการครับ แนะนำให้ตรวจด้วย Play Protect ด้วย"
            }
            main.post { speakAndResume(reply) }
        }.start()
    }

    private fun speakAndResume(text: String) {
        updateStatus(text)
        if (!ttsReady) {
            scheduleListen(1000)
            return
        }
        try {
            speaking = true
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_answer")
        } catch (_: Exception) {
            speaking = false
            scheduleListen(900)
        }
    }

    private fun speak(text: String) {
        if (!ttsReady) return
        try {
            speaking = true
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_stop")
        } catch (_: Exception) { }
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val result = tts.setLanguage(Locale("th", "TH"))
        ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) {
                main.post {
                    speaking = false
                    if (!stopping && utteranceId == "jarvis_answer") scheduleListen(450)
                }
            }
            override fun onError(utteranceId: String?) {
                main.post {
                    speaking = false
                    if (!stopping) scheduleListen(700)
                }
            }
        })
        // JARVIS-style default: calm, low, measured assistant voice.
        // We cannot clone the movie voice; the actual voice depends on voices installed on Android.
        val preferred = tts.voices?.sortedWith(compareBy<android.speech.tts.Voice> {
            if (it.locale.language == "th") 0 else 1
        }.thenBy {
            if (it.name.lowercase(Locale.ROOT).contains("female")) 1 else 0
        })?.firstOrNull { !it.isNetworkConnectionRequired }
        if (preferred != null) tts.voice = preferred
        tts.setSpeechRate(0.94f)
        tts.setPitch(0.94f)
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!stopping) {
            try {
                val restart = Intent(applicationContext, JarvisVoiceService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) applicationContext.startForegroundService(restart)
                else applicationContext.startService(restart)
            } catch (_: Exception) { }
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopping = false
        if (recognizer == null) createRecognizer()
        return START_STICKY
    }

    override fun onDestroy() {
        stopping = true
        HeyAccessibilityService.current?.setListeningIndicator(false)
        waitingForCommand = false
        main.removeCallbacksAndMessages(null)
        destroyRecognizer()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun updateStatus(text: String) {
        MainActivity.instance?.runOnUiThread {
            MainActivity.instance?.setBackgroundStatus(text)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "JARVIS เบื้องหลัง",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "JARVIS ใช้ไมโครโฟนเพื่อรอคำปลุก" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("JARVIS ทำงานเบื้องหลัง")
                .setContentText("รอ Hey AI หรือ จาร์วิส")
                .setContentIntent(open)
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("JARVIS ทำงานเบื้องหลัง")
                .setContentText("รอ Hey AI หรือ จาร์วิส")
                .setContentIntent(open)
                .setOngoing(true)
                .build()
        }
    }

    companion object {
        const val CHANNEL_ID = "jarvis_background"
        const val NOTIFICATION_ID = 4201
    }
}
