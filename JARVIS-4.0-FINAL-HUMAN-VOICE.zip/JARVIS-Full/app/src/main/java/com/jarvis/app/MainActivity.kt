package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var answer: TextView
    private lateinit var tts: TextToSpeech
    private var oneShotRecognizer: SpeechRecognizer? = null
    private val main = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
        tts = TextToSpeech(this, this)
        showCosmicSplash()
    }

    private fun showCosmicSplash() {
        val splash = android.widget.ImageView(this).apply {
            setImageResource(R.drawable.jarvis_splash)
            scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(android.graphics.Color.rgb(18, 5, 31))
        }
        setContentView(splash)
        main.postDelayed({ buildUi(); requestNeededPermissions() }, 2200)
    }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) permissions += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) permissions += Manifest.permission.POST_NOTIFICATIONS
        if (permissions.isNotEmpty()) requestPermissions(permissions.toTypedArray(), 9001)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(28, 28, 28, 20) }
        val title = TextView(this).apply { text = "🤖 JARVIS"; textSize = 30f; gravity = Gravity.CENTER; setPadding(0, 10, 0, 12) }
        status = TextView(this).apply { text = "พร้อมทำงาน"; textSize = 17f; setPadding(0, 0, 0, 12) }
        val background = Button(this).apply { text = "🎙️ เปิด JARVIS เบื้องหลัง"; setOnClickListener { startBackgroundListening() } }
        val stop = Button(this).apply { text = "⏹️ หยุด JARVIS เบื้องหลัง"; setOnClickListener { stopBackgroundListening() } }
        val listen = Button(this).apply { text = "🎤 พูดกับ JARVIS"; setOnClickListener { listenWithoutSystemUi() } }
        val read = Button(this).apply { text = "👁️ ดูหน้าจอนี้"; setOnClickListener { readScreen(true) } }
        val security = Button(this).apply { text = "🛡️ ตรวจความปลอดภัย"; setOnClickListener { runSecurityScan(true) } }
        val access = Button(this).apply { text = "⚙️ เปิดสิทธิ์อ่านหน้าจอ"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        answer = TextView(this).apply { text = "JARVIS พร้อมรับคำสั่ง"; textSize = 17f; setPadding(0, 14, 0, 14) }
        root.addView(title); root.addView(status); root.addView(background); root.addView(stop); root.addView(listen); root.addView(read); root.addView(security); root.addView(access); root.addView(answer, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun startBackgroundListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 9001); return }
        val intent = Intent(this, JarvisVoiceService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            status.text = "🟢 JARVIS ทำงานเบื้องหลังแล้ว"
            answer.text = "ปิดหน้าแอปได้ แล้วพูดว่า “Hey AI” หรือ “จาร์วิส”"
        } catch (e: Exception) { status.text = "เริ่มเบื้องหลังไม่สำเร็จ"; answer.text = e.message ?: "เกิดข้อผิดพลาด" }
    }

    private fun stopBackgroundListening() {
        stopService(Intent(this, JarvisVoiceService::class.java))
        status.text = "⏹️ หยุด JARVIS แล้ว"
        answer.text = "โหมดเบื้องหลังถูกปิด"
    }

    fun setBackgroundStatus(text: String) { if (::status.isInitialized) status.text = "🟢 $text"; if (::answer.isInitialized) answer.text = text }

    /** Uses Android SpeechRecognizer directly; it does not launch the large speech dialog. */
    private fun listenWithoutSystemUi() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 9001); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { respond("เครื่องนี้ไม่มีระบบรับเสียงครับ"); return }
        oneShotRecognizer?.destroy()
        oneShotRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        oneShotRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "🟢 กำลังฟัง…" }
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() { status.text = "กำลังประมวลผล…" }
            override fun onError(error: Int) { status.text = "พร้อมทำงาน"; oneShotRecognizer?.destroy(); oneShotRecognizer = null; if (error != SpeechRecognizer.ERROR_NO_MATCH) respond("ผมรับเสียงไม่สำเร็จครับ ลองพูดอีกครั้ง") }
            override fun onResults(results: Bundle?) {
                val candidates = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                val parsed = candidates.asSequence().map { raw -> JarvisBrain.parse(JarvisBrain.stripWake(raw).second) }.firstOrNull { it.action != JarvisBrain.Action.UNKNOWN }
                oneShotRecognizer?.destroy(); oneShotRecognizer = null
                if (parsed != null) execute(parsed) else respond("ผมยังไม่เข้าใจครับ ลองพูดใหม่ได้เลย")
            }
            override fun onPartialResults(partialResults: Bundle?) = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "th-TH")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
        }
        try { oneShotRecognizer?.startListening(i) } catch (_: Exception) { oneShotRecognizer?.destroy(); oneShotRecognizer = null; respond("ผมเริ่มรับเสียงไม่ได้ครับ") }
    }

    private fun execute(result: JarvisBrain.Result) {
        status.text = result.reply
        when (result.action) {
            JarvisBrain.Action.SCREEN -> readScreen(true)
            JarvisBrain.Action.HOME -> { if (HeyAccessibilityService.current?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME) != true) startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)); speak(result.reply) }
            JarvisBrain.Action.BACK -> { HeyAccessibilityService.current?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK); speak(result.reply) }
            JarvisBrain.Action.SETTINGS -> { startActivity(Intent(Settings.ACTION_SETTINGS)); speak(result.reply) }
            JarvisBrain.Action.YOUTUBE -> openApp("com.google.android.youtube", "YouTube")
            JarvisBrain.Action.ROBLOX -> openApp("com.roblox.client", "Roblox")
            JarvisBrain.Action.OPEN_APP -> openAnyApp(result.target)
            JarvisBrain.Action.SECURITY -> runSecurityScan(true)
            JarvisBrain.Action.TIME, JarvisBrain.Action.GREETING, JarvisBrain.Action.HELP, JarvisBrain.Action.BATTERY -> {
                if (result.action == JarvisBrain.Action.BATTERY) speakBattery() else respond(result.reply)
            }
            JarvisBrain.Action.STOP -> stopBackgroundListening()
            JarvisBrain.Action.UNKNOWN -> respond(result.reply)
        }
    }

    private fun openApp(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch == null) { respond("ผมหาแอป $label ในเครื่องไม่เจอครับ") ; return }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try { startActivity(launch); status.text = "กำลังเปิด $label…"; speak("กำลังเปิด $label ครับ") }
        catch (_: Exception) { respond("เปิด $label ไม่สำเร็จครับ") }
    }

    private fun openAnyApp(label: String) {
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val info = packageManager.queryIntentActivities(launcherIntent, 0).firstOrNull {
            val actual = packageManager.getApplicationLabel(it.activityInfo.applicationInfo).toString()
            actual.equals(label, true) || actual.contains(label, true) || label.contains(actual, true)
        }
        if (info == null) { respond("ผมหาแอป $label ในเครื่องไม่เจอครับ"); return }
        val launch = Intent(launcherIntent).setClassName(info.activityInfo.packageName, info.activityInfo.name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try { startActivity(launch); status.text = "กำลังเปิด $label…"; speak("กำลังเปิด $label ครับ") } catch (_: Exception) { respond("เปิด $label ไม่สำเร็จครับ") }
    }

    private fun speakBattery() {
        val bm = getSystemService(BATTERY_SERVICE) as android.os.BatteryManager
        val level = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
        respond("ตอนนี้แบตเตอรี่ประมาณ $level เปอร์เซ็นต์ครับ")
    }

    private fun respond(text: String) { answer.text = text; status.text = text; speak(text) }

    fun readScreen(speakResult: Boolean = false) {
        val text = HeyAccessibilityService.current?.readVisibleText() ?: "ยังไม่ได้เปิดสิทธิ์อ่านหน้าจอครับ"
        val summary = JarvisBrain.screenReply(text)
        answer.text = summary
        status.text = "อ่านหน้าจอแล้ว"
        if (speakResult) speak(summary.take(1000))
    }

    fun refreshScreenSummary() { if (::status.isInitialized) status.text = "🟢 JARVIS พร้อมอ่านหน้าจอ" }

    private fun runSecurityScan(speakResult: Boolean) {
        Thread {
            val findings = JarvisSecurityScanner.scan(packageManager)
            val text = if (findings.isEmpty()) "ยังไม่พบสัญญาณน่าสงสัยจากการตรวจเบื้องต้นครับ" else "พบแอปที่ควรตรวจสอบเพิ่มเติม ${findings.size} รายการครับ"
            runOnUiThread { answer.text = text; status.text = "ตรวจเบื้องต้นแล้ว"; if (speakResult) speak(text) }
        }.start()
    }

    private fun speak(text: String) { if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis") }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("th", "TH")
            val preferred = tts.voices?.sortedWith(compareBy<android.speech.tts.Voice> {
                if (it.locale.language == "th") 0 else 1
            }.thenBy { if (it.name.lowercase(Locale.ROOT).contains("female")) 1 else 0 })
                ?.firstOrNull { !it.isNetworkConnectionRequired }
            if (preferred != null) tts.voice = preferred
            tts.setSpeechRate(0.94f)
            tts.setPitch(0.94f)
        }
    }

    override fun onDestroy() {
        oneShotRecognizer?.destroy(); oneShotRecognizer = null
        if (::tts.isInitialized) tts.shutdown()
        instance = null
        super.onDestroy()
    }

    companion object { var instance: MainActivity? = null }
}
