package com.jarvis.app

import java.text.Normalizer
import java.util.Locale

/** Local intent + conversation brain. It understands natural Thai phrasing without requiring exact commands. */
object JarvisBrain {
    enum class Action { SCREEN, HOME, BACK, SETTINGS, YOUTUBE, ROBLOX, OPEN_APP, SECURITY, STOP, GREETING, TIME, BATTERY, HELP, CHAT, UNKNOWN }
    data class Result(val action: Action, val reply: String, val target: String = "")

    private var lastTopic = ""

    fun parse(raw: String): Result {
        val c = normalize(raw)
        if (c.isBlank()) return Result(Action.UNKNOWN, "ผมไม่ได้ยินคำพูดครับ")

        if (hasAny(c, "สวัสดี", "หวัดดี", "ฮัลโหล", "hello", "hi") && c.length <= 60)
            return remember(Result(Action.GREETING, "สวัสดีครับ มีอะไรให้ผมช่วยไหมครับ"), "ทักทาย")
        if (hasAny(c, "ขอบคุณ", "ขอบใจ", "แต๊งกิ้ว", "thank you"))
            return remember(Result(Action.CHAT, "ยินดีครับ งานของผมคือช่วยคุณ ไม่ได้มีค่าบริการเป็นขนมด้วยนะครับ 😄"), "ขอบคุณ")
        if (hasAny(c, "นายชื่ออะไร", "ชื่ออะไร", "ชื่อของนาย", "เรียกนายว่าอะไร"))
            return remember(Result(Action.CHAT, "ผมคือ JARVIS ครับ ผู้ช่วยส่วนตัวของคุณ"), "ตัวตน")
        if (hasAny(c, "ทำอะไรได้บ้าง", "ช่วยอะไรได้บ้าง", "ใช้งานยังไง", "วิธีใช้", "สอนใช้"))
            return remember(Result(Action.HELP, "ผมรับคำพูดแบบธรรมชาติได้ครับ เช่น เปิดแอป ดูหน้าจอ กลับหน้าหลัก ย้อนกลับ เปิดการตั้งค่า ตรวจแบต และคุยโต้ตอบแบบง่าย ๆ"), "ความสามารถ")
        if (hasAny(c, "กี่โมง", "เวลาเท่าไหร่", "เวลาอะไร"))
            return remember(Result(Action.TIME, "ตอนนี้เวลา ${java.text.SimpleDateFormat("HH:mm", Locale("th", "TH")).format(java.util.Date())} นาฬิกาครับ"), "เวลา")
        if (hasAny(c, "แบต", "แบตเตอรี่", "แบตเหลือเท่าไหร่", "แบตเหลือกี่เปอร์เซ็นต์"))
            return remember(Result(Action.BATTERY, "กำลังตรวจสอบแบตเตอรี่ครับ"), "แบตเตอรี่")
        if (hasAny(c, "ดูหน้าจอ", "หน้าจอนี้", "เห็นอะไรบนหน้าจอ", "อ่านหน้าจอ", "ดูจอ", "อ่านจอ", "เช็กหน้าจอ", "ตรวจหน้าจอ"))
            return remember(Result(Action.SCREEN, "ได้ครับ เดี๋ยวผมดูหน้าจอให้"), "หน้าจอ")
        if (hasAny(c, "กลับหน้าหลัก", "กลับบ้าน", "หน้าหลัก", "โฮม", "กลับโฮม"))
            return remember(Result(Action.HOME, "ได้ครับ กำลังกลับหน้าหลัก"), "นำทาง")
        if (hasAny(c, "ย้อนกลับ", "กดย้อนกลับ", "กลับไปเมื่อกี้", "กลับไปหน้าก่อน", "back"))
            return remember(Result(Action.BACK, "ได้ครับ กำลังย้อนกลับ"), "นำทาง")
        if (hasAny(c, "เปิดการตั้งค่า", "เปิดตั้งค่า", "เปิด settings", "เข้า settings", "ตั้งค่า"))
            return remember(Result(Action.SETTINGS, "กำลังเปิดการตั้งค่าครับ"), "การตั้งค่า")
        if (isYouTubeCommand(c)) return remember(Result(Action.YOUTUBE, "กำลังเปิด YouTube ครับ", "YouTube"), "YouTube")
        if (isRobloxCommand(c)) return remember(Result(Action.ROBLOX, "กำลังเปิด Roblox ครับ", "Roblox"), "Roblox")
        if (hasAny(c, "ตรวจไวรัส", "สแกนไวรัส", "ตรวจสอบไวรัส", "ตรวจความปลอดภัย", "เช็คไวรัส", "เช็กไวรัส", "เช็คความปลอดภัย", "เช็กความปลอดภัย"))
            return remember(Result(Action.SECURITY, "กำลังตรวจสอบความปลอดภัยเบื้องต้นครับ"), "ความปลอดภัย")
        if (hasAny(c, "หยุดฟัง", "ปิดโหมดฟัง", "หยุดทำงานเบื้องหลัง", "หยุดจาร์วิส", "หยุดจาวิส"))
            return remember(Result(Action.STOP, "ได้ครับ ผมจะหยุดการฟังเบื้องหลัง"), "หยุดทำงาน")

        val appName = extractAppName(c)
        if (appName.isNotBlank()) return remember(Result(Action.OPEN_APP, "กำลังเปิด $appName ครับ", appName), "เปิดแอป")

        // Simple conversational understanding: if the user is explaining, asking for help,
        // or referring to the previous topic, answer naturally instead of exposing an internal command.
        if (hasAny(c, "ช่วยหน่อย", "ช่วยผม", "ช่วยที", "ทำยังไง", "ต้องทำยังไง", "หมายถึงอะไร", "คืออะไร", "อธิบาย", "เข้าใจไหม", "ฟังอยู่ไหม")) {
            val topic = if (lastTopic.isNotBlank()) " เรื่อง$lastTopic" else ""
            return remember(Result(Action.CHAT, "เข้าใจครับ$topic ถ้าต้องการให้ผมทำอะไรต่อ บอกผมเป็นภาษาปกติได้เลยครับ"), lastTopic)
        }
        if (c.length >= 12) {
            return remember(Result(Action.CHAT, "รับทราบครับ ผมจับใจความไว้แล้ว ถ้าต้องการให้ผมลงมือทำอะไรต่อ บอกได้เลยครับ"), lastTopic)
        }
        return Result(Action.UNKNOWN, "ผมยังไม่แน่ใจว่าต้องการให้ทำอะไรครับ ลองบอกผมอีกนิดได้เลย")
    }

    fun playfulReply(userText: String, base: String): String {
        val c = normalize(userText)
        if (hasAny(c, "ทำผิด", "พลาด", "ทำไม่ได้", "ไม่ได้อีกแล้ว")) return "$base แต่ดูเหมือนวันนี้ผมจะได้ออกกำลังกายสมองเพิ่มแล้วครับ 😏"
        if (hasAny(c, "ตลก", "มุก", "555", "ฮา")) return "$base ถ้ามุกนี้ไม่ขำ ผมขอเรียกว่าเป็นการทดสอบระบบนะครับ 😏"
        return base
    }

    fun screenReply(screenText: String): String {
        val clean = screenText.lines().map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(18)
        if (clean.isEmpty()) return "ผมเห็นหน้าจอแล้วครับ แต่ยังไม่มีข้อความที่อ่านได้"
        val joined = clean.joinToString(" ")
        val joke = when {
            Regex("555+|ฮา|ตลก|มีม|meme", RegexOption.IGNORE_CASE).containsMatchIn(joined) -> "เห็นแล้วครับ… หน้าจอนี้ดูเหมือนจะพยายามทำให้ผมขำอยู่นะครับ 😏"
            joined.length > 450 -> "ผมอ่านได้หลายส่วนครับ หน้าจอนี้มีข้อมูลค่อนข้างเยอะ เดี๋ยวผมสรุปส่วนสำคัญให้"
            else -> "ผมอ่านหน้าจอให้แล้วครับ มีข้อความและองค์ประกอบที่ผมเข้าถึงได้หลายรายการ"
        }
        return "$joke\n${clean.take(10).joinToString(" • ").take(700)}"
    }

    fun stripWake(raw: String): Pair<Boolean, String> {
        val c = normalize(raw)
        val wake = listOf("hey ai", "heyai", "เฮ้เอไอ", "เฮ้ เอไอ", "จาร์วิส", "จาวิส", "จาวีส", "จาร์วีส")
        val found = wake.firstOrNull { c.contains(it) } ?: return false to c
        val command = c.substringAfter(found).trim(' ', ',', '.', '!', '?', ':', ';', '-', '_', '/', '\\')
        return true to command
    }

    fun normalize(raw: String): String {
        var s = Normalizer.normalize(raw.lowercase(Locale.ROOT), Normalizer.Form.NFKC)
        s = s.replace("\u200b", "").replace("\ufeff", "").replace(Regex("[\\p{C}]"), " ")
        s = s.replace("ยูทู๊ป", "ยูทูป").replace("ยูทู๊บ", "ยูทูบ").replace("ยู ทูป", "ยูทูป").replace("ยู ทูบ", "ยูทูบ")
            .replace("ยูทูปป์", "ยูทูป").replace("ยูทูปป", "ยูทูป")
            .replace("โรบลอก", "โรบล็อก").replace("โรบอก", "โรบล็อก")
        return s.replace(Regex("\\s+"), " ").trim()
    }

    private fun isYouTubeCommand(s: String): Boolean {
        if (!hasAny(s, "เปิด", "เข้า", "ไปที่", "ไปดู", "ดู", "เล่น")) return false
        val compact = s.replace(" ", "")
        return listOf("youtube", "ยูทูป", "ยูทูบ").any { compact.contains(it) } || fuzzyContains(compact, listOf("ยูทูป", "ยูทูบ", "youtube"))
    }

    private fun isRobloxCommand(s: String): Boolean {
        if (!hasAny(s, "เปิด", "เข้า", "ไปที่", "ไปเล่น", "เล่น")) return false
        val compact = s.replace(" ", "")
        return listOf("roblox", "โรบล็อก").any { compact.contains(it) } || fuzzyContains(compact, listOf("โรบล็อก", "roblox"))
    }

    private fun extractAppName(s: String): String {
        if (!hasAny(s, "เปิด", "เข้า", "ไปที่", "ไปยัง", "เปิดให้หน่อย", "ช่วยเปิด")) return ""
        var x = s
        listOf("ช่วยเปิด", "เปิดให้หน่อย", "เปิด", "เข้าไปที่", "เข้า", "ไปที่", "ไปยัง").forEach { x = x.replace(it, " ") }
        x = x.replace(Regex("\\bให้หน่อย\\b"), "").trim()
        if (x.length < 2 || x.length > 50) return ""
        if (listOf("youtube", "ยูทูป", "ยูทูบ", "roblox", "โรบล็อก", "settings", "ตั้งค่า").any { x.contains(it) }) return ""
        return x
    }

    private fun remember(result: Result, topic: String): Result {
        if (topic.isNotBlank()) lastTopic = topic
        return result
    }

    private fun fuzzyContains(text: String, targets: List<String>): Boolean {
        for (target in targets) {
            val n = target.length
            if (text.length < n) continue
            for (i in 0..(text.length - n)) {
                if (levenshtein(text.substring(i, i + n), target) <= if (target.length >= 6) 2 else 1) return true
            }
        }
        return false
    }

    private fun hasAny(s: String, vararg words: String) = words.any { s.contains(it) }

    private fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        var prev = IntArray(b.length + 1) { it }
        for (i in a.indices) {
            val cur = IntArray(b.length + 1); cur[0] = i + 1
            for (j in b.indices) cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + if (a[i] == b[j]) 0 else 1)
            prev = cur
        }
        return prev[b.length]
    }
}
