# JARVIS 4.0 — Final Local Assistant

JARVIS 4.0 is a personal Android assistant prototype with a JARVIS-inspired personality: calm, precise, polite, and lightly playful when appropriate.

## Voice
The default Android TTS profile is deliberately measured and low-pitched. It does not clone the movie JARVIS voice; the exact timbre depends on voices installed on the phone.

## Behaviour
- Wake phrases: “Hey AI” and “จาร์วิส”
- Background foreground-service speech recognition without launching the large speech dialog from the app
- Conservative command filtering
- Small white listening dot through Accessibility overlay
- YouTube and Roblox launching
- Accessibility screen-text reading with short summaries and situational responses
- Real Home/Back actions through Accessibility when permission is enabled
- Natural Thai phrasing, lightweight context, and conversational fallback
- Short situational jokes / teasing instead of internal debug text

## What this build does not claim
This is a local Android assistant, not a full ChatGPT replacement. It understands many natural Thai phrasings and can keep a small local topic context, but arbitrary knowledge questions still require an online AI backend. Screen understanding is based on Accessibility text/labels; it is not camera/image vision.

## Important Android limits
SpeechRecognizer is not a dedicated low-power always-on hotword engine. Android may also impose background restrictions. Screen understanding currently uses visible Accessibility text; full image understanding requires an online vision model connection.
