# JARVIS – Android Assistant

Current MVP:
- App name: JARVIS
- Voice commands can be introduced with “Hey AI”, “HeyAI”, “JARVIS”, or “จาร์วิส”.
- Text-to-Speech response plus on-screen text.
- Prefers a Thai voice marked female when the installed TTS engine provides one; Android may use its default voice otherwise.
- Basic offline command handling for Home, Settings, YouTube, Roblox, and screen reading after Accessibility permission.
- Accessibility service reads visible text/content descriptions.
- `accessibility_config.xml` uses a valid `@string/...` description resource.

Planned next stages:
- Better offline speech recognition using an on-device engine/model when available.
- Online AI backend and vision analysis.
- Screenshot analysis.
- External camera/device integration where the device/protocol supports it.
