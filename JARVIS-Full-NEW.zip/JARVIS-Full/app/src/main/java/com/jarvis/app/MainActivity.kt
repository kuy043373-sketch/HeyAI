package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var answer: TextView
    private lateinit var tts: TextToSpeech
    private val voiceRequest = 7001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
        tts = TextToSpeech(this, this)
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 9001)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 28, 28, 20)
        }
        val title = TextView(this).apply { text = "🤖 JARVIS"; textSize = 30f; gravity = Gravity.CENTER; setPadding(0, 10, 0, 18) }
        status = TextView(this).apply { text = "พร้อมทำงาน • Offline commands พร้อมใช้งาน"; textSize = 17f; setPadding(0, 0, 0, 12) }
        val listen = Button(this).apply { text = "🎙️ พูดกับ JARVIS"; setOnClickListener { listen() } }
        val read = Button(this).apply { text = "👁️ ดูหน้าจอนี้"; setOnClickListener { readScreen(true) } }
        val access = Button(this).apply { text = "⚙️ เปิดสิทธิ์อ่านหน้าจอ"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        answer = TextView(this).apply { text = "คำตอบของ JARVIS จะแสดงตรงนี้"; textSize = 17f; setPadding(0, 18, 0, 18) }
        root.addView(title); root.addView(status); root.addView(listen); root.addView(read); root.addView(access); root.addView(answer, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "พูดคำสั่งกับ JARVIS")
        }
        try { startActivityForResult(i, voiceRequest) } catch (_: Exception) { speak("เครื่องนี้ไม่มีระบบรับเสียง") }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != voiceRequest || resultCode != RESULT_OK) return
        val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.trim().orEmpty()
        handleCommand(text)
    }

    private fun handleCommand(command: String) {
        val normalized = command.lowercase(Locale.getDefault())
            .replace("hey ai", "")
            .replace("heyai", "")
            .replace("จาร์วิส", "")
            .replace("jarvis", "")
            .trim()
        status.text = "คำสั่ง: $command"
        when {
            normalized.contains("ดูหน้าจอ") || normalized.contains("หน้าจอนี้") || normalized.contains("เห็นอะไร") -> readScreen(true)
            normalized.contains("กลับหน้าหลัก") || normalized == "หน้าหลัก" -> { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)); respond("กลับหน้าหลักแล้ว") }
            normalized.contains("เปิดการตั้งค่า") || normalized.contains("เปิด settings") -> { startActivity(Intent(Settings.ACTION_SETTINGS)); respond("เปิดการตั้งค่าแล้ว") }
            normalized.contains("เปิด youtube") -> { openApp("com.google.android.youtube", "YouTube") }
            normalized.contains("เปิด roblox") -> { openApp("com.roblox.client", "Roblox") }
            normalized.contains("เปิด") -> respond("โหมด Offline รองรับคำสั่งเปิดแอปพื้นฐาน และเราจะเพิ่มแอปได้อีก")
            else -> respond("ตอนนี้ JARVIS ใช้คำสั่งพื้นฐานแบบ Offline ได้ ส่วน AI ออนไลน์จะเพิ่มในขั้นต่อไป")
        }
    }

    private fun openApp(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) { startActivity(launch); respond("เปิด$labelแล้ว") }
        else respond("ยังไม่พบแอป$labelในเครื่อง")
    }

    private fun respond(text: String) { answer.text = text; speak(text) }

    fun readScreen(speakResult: Boolean = false) {
        val text = HeyAccessibilityService.current?.readVisibleText() ?: "ยังไม่ได้เปิดสิทธิ์อ่านหน้าจอ"
        answer.text = text
        if (speakResult) speak(if (text.length > 400) text.take(400) else text)
    }

    fun refreshScreenSummary() {
        if (::answer.isInitialized) runOnUiThread { answer.text = HeyAccessibilityService.current?.readVisibleText() ?: "ยังไม่ได้เปิดสิทธิ์อ่านหน้าจอ" }
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("th", "TH")
            // Prefer a female-sounding Thai voice when the installed Android TTS engine provides one.
            val voices = tts.voices ?: emptySet()
            val female = voices.firstOrNull { v ->
                v.locale.language == "th" && v.name.lowercase(Locale.ROOT).contains("female")
            }
            if (female != null) tts.voice = female
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        instance = null
        super.onDestroy()
    }

    companion object { var instance: MainActivity? = null }
}
